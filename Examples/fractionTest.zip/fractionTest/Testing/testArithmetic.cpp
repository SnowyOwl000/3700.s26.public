//
// Created by Robert Kramer on 1/22/26.
//

#include <numeric>
#include <random>
#include <gtest/gtest.h>
#include "fraction.h"

const int32_t
    NUM_RANDOM = 10000000;

TEST(FractionTestSuite,AddGrid) {
    Fraction a,b,c;

    for (int32_t n1=-50;n1<=50;n1++) {
        for (int32_t d1=-50;d1<=50;d1++) {
            if (d1 == 0)
                continue;
            a = Fraction(n1,d1);
            for (int32_t n2=-50;n2<=50;n2++) {
                for (int32_t d2=-50;d2<=50;d2++) {
                    if (d2 == 0)
                        continue;
                    b = Fraction(n2,d2);

                    c = a + b;

                    int32_t
                        ns = n1 * d2 + n2 * d1,
                        ds = d1 * d2,
                        gs = std::gcd(ns,ds);

                    if (ds < 0) {
                        ns = -ns;
                        ds = -ds;
                    }

                    ns /= gs;
                    ds /= gs;

                    GTEST_ASSERT_EQ(c.getNum(), ns);
                    GTEST_ASSERT_EQ(c.getDen(), ds);
                }
            }
        }
    }

    //std::cout << "Passed - Addition grid" << std::endl;
}

TEST(FractionTestSuite,AddRandom) {
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<>
        dis(-32768,32768);
    Fraction a,b,c;

    for (int32_t i=0;i<NUM_RANDOM;i++) {
        int32_t
            n1 = dis(mt),
            n2 = dis(mt),
            d1,d2;

        do {
            d1 = dis(mt);
        } while (d1 == 0);

        do {
            d2 = dis(mt);
        } while (d2 == 0);

        a = Fraction(n1,d1);
        b = Fraction(n2,d2);

        c = a + b;

        int32_t
            ns = n1 * d2 + n2 * d1,
            ds = d1 * d2,
            gs = std::gcd(ns,ds);

        if (ds < 0) {
            ns = -ns;
            ds = -ds;
        }

        ns /= gs;
        ds /= gs;

        GTEST_ASSERT_EQ(c.getNum(), ns);
        GTEST_ASSERT_EQ(c.getDen(), ds);
    }

    //std::cout << "Passed - Addition random" << std::endl;
}

TEST(FractionTestSuite,SubGrid) {
    Fraction a,b,c;

    for (int32_t n1=-50;n1<=50;n1++) {
        for (int32_t d1=-50;d1<=50;d1++) {
            if (d1 == 0)
                continue;
            a = Fraction(n1,d1);
            for (int32_t n2=-50;n2<=50;n2++) {
                for (int32_t d2=-50;d2<=50;d2++) {
                    if (d2 == 0)
                        continue;
                    b = Fraction(n2,d2);

                    c = a - b;

                    int32_t
                        ns = n1 * d2 - n2 * d1,
                        ds = d1 * d2,
                        gs = std::gcd(ns,ds);

                    if (ds < 0) {
                        ns = -ns;
                        ds = -ds;
                    }

                    ns /= gs;
                    ds /= gs;

                    GTEST_ASSERT_EQ(c.getNum(), ns);
                    GTEST_ASSERT_EQ(c.getDen(), ds);
                }
            }
        }
    }

    //std::cout << "Passed - Subtraction grid" << std::endl;
}

TEST(FractionTestSuite,SubRandom) {
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<>
        dis(-32768,32768);
    Fraction a,b,c;

    for (int32_t i=0;i<NUM_RANDOM;i++) {
        int32_t
            n1 = dis(mt),
            n2 = dis(mt),
            d1,d2;

        do {
            d1 = dis(mt);
        } while (d1 == 0);

        do {
            d2 = dis(mt);
        } while (d2 == 0);

        a = Fraction(n1,d1);
        b = Fraction(n2,d2);

        c = a - b;

        int32_t
            ns = n1 * d2 - n2 * d1,
            ds = d1 * d2,
            gs = std::gcd(ns,ds);

        if (ds < 0) {
            ns = -ns;
            ds = -ds;
        }

        ns /= gs;
        ds /= gs;

        GTEST_ASSERT_EQ(c.getNum(), ns);
        GTEST_ASSERT_EQ(c.getDen(), ds);
    }

    //std::cout << "Passed - Subtraction random" << std::endl;
}

TEST(FractionTestSuite,MulGrid) {
    Fraction a,b,c;

    for (int32_t n1=-50;n1<=50;n1++) {
        for (int32_t d1=-50;d1<=50;d1++) {
            if (d1 == 0)
                continue;
            a = Fraction(n1,d1);
            for (int32_t n2=-50;n2<=50;n2++) {
                for (int32_t d2=-50;d2<=50;d2++) {
                    if (d2 == 0)
                        continue;
                    b = Fraction(n2,d2);

                    c = a * b;

                    int32_t
                        ns = n1 * n2,
                        ds = d1 * d2,
                        gs = std::gcd(ns,ds);

                    if (ds < 0) {
                        ns = -ns;
                        ds = -ds;
                    }

                    ns /= gs;
                    ds /= gs;

                    GTEST_ASSERT_EQ(c.getNum(), ns);
                    GTEST_ASSERT_EQ(c.getDen(), ds);
                }
            }
        }
    }

    //std::cout << "Passed - Multiplication grid" << std::endl;
}

TEST(FractionTestSuite,MulRandom) {
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<>
        dis(-32768,32768);
    Fraction a,b,c;

    for (int32_t i=0;i<NUM_RANDOM;i++) {
        int32_t
            n1 = dis(mt),
            n2 = dis(mt),
            d1,d2;

        do {
            d1 = dis(mt);
        } while (d1 == 0);

        do {
            d2 = dis(mt);
        } while (d2 == 0);

        a = Fraction(n1,d1);
        b = Fraction(n2,d2);

        c = a * b;

        int32_t
            ns = n1 * n2,
            ds = d1 * d2,
            gs = std::gcd(ns,ds);

        if (ds < 0) {
            ns = -ns;
            ds = -ds;
        }

        ns /= gs;
        ds /= gs;

        GTEST_ASSERT_EQ(c.getNum(), ns);
        GTEST_ASSERT_EQ(c.getDen(), ds);
    }

    //std::cout << "Passed - Multiplication random" << std::endl;
}

TEST(FractionTestSuite,DivGrid) {
    Fraction a,b,c;

    for (int32_t n1=-50;n1<=50;n1++) {
        for (int32_t d1=-50;d1<=50;d1++) {
            if (d1 == 0)
                continue;
            a = Fraction(n1,d1);
            for (int32_t n2=-50;n2<=50;n2++) {
                if (n2 == 0)
                    continue;
                for (int32_t d2=-50;d2<=50;d2++) {
                    b = Fraction(n2,d2);

                    c = a / b;

                    int32_t
                        ns = n1 * d2,
                        ds = d1 * n2,
                        gs = std::gcd(ns,ds);

                    if (ds < 0) {
                        ns = -ns;
                        ds = -ds;
                    }

                    ns /= gs;
                    ds /= gs;

                    GTEST_ASSERT_EQ(c.getNum(), ns);
                    GTEST_ASSERT_EQ(c.getDen(), ds);
                }
            }
        }
    }

    //std::cout << "Passed - Division grid" << std::endl;
}

TEST(FractionTestSuite,DivRandom) {
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<>
        dis(-32768,32768);
    Fraction a,b,c;

    for (int32_t i=0;i<NUM_RANDOM;i++) {
        int32_t
            n1 = dis(mt),
            d2 = dis(mt),
            d1,n2;

        do {
            d1 = dis(mt);
        } while (d1 == 0);

        do {
            n2 = dis(mt);
        } while (n2 == 0);

        a = Fraction(n1,d1);
        b = Fraction(n2,d2);

        c = a / b;

        int32_t
            ns = n1 * d2,
            ds = d1 * n2,
            gs = std::gcd(ns,ds);

        if (ds < 0) {
            ns = -ns;
            ds = -ds;
        }

        ns /= gs;
        ds /= gs;

        GTEST_ASSERT_EQ(c.getNum(), ns);
        GTEST_ASSERT_EQ(c.getDen(), ds);
    }

    //std::cout << "Passed - Division random" << std::endl;
}
