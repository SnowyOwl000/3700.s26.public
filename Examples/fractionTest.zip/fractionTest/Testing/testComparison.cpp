//
// Created by Robert Kramer on 1/22/26.
//

#include <numeric>
#include <random>
#include <gtest/gtest.h>
#include "fraction.h"

const int32_t
    NUM_RANDOM = 10000000;

TEST(FractionTestSuite,EqGrid) {
    Fraction a,b;

    for (int32_t n1=-50;n1<=50;n1++) {
        for (int32_t d1=-50;d1<=50;d1++) {
            if (d1 == 0)
                continue;
            a = Fraction(n1,d1);
            for (int32_t n2=-50;n2<=50;n2++) {
                for (int32_t d2=-50;d2<=50;d2++) {
                    if (d2 == 0)
                        continue;
                    b = Fraction(n2,d2);

                    GTEST_ASSERT_TRUE((a == b) == (n1*d2 == n2*d1));
                }
            }
        }
    }

    //std::cout << "Passed - == grid" << std::endl;
}

TEST(FractionTestSuite,EqRandom) {
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<>
        dis(-32768,32768);
    Fraction a,b;

    for (int32_t i=0;i<NUM_RANDOM;i++) {
        int32_t
            n1 = dis(mt),
            n2 = dis(mt),
            d1,d2;

        do {
            d1 = dis(mt);
        } while (d1 == 0);

        do {
            d2 = dis(mt);
        } while (d2 == 0);

        a = Fraction(n1,d1);
        b = Fraction(n2,d2);

        GTEST_ASSERT_TRUE((a == b) == (n1*d2 == n2*d1));
    }

    //std::cout << "Passed - == random" << std::endl;
}

TEST(FractionTestSuite,NeGrid) {
    Fraction a,b;

    for (int32_t n1=-50;n1<=50;n1++) {
        for (int32_t d1=-50;d1<=50;d1++) {
            if (d1 == 0)
                continue;
            a = Fraction(n1,d1);
            for (int32_t n2=-50;n2<=50;n2++) {
                for (int32_t d2=-50;d2<=50;d2++) {
                    if (d2 == 0)
                        continue;
                    b = Fraction(n2,d2);

                    GTEST_ASSERT_TRUE((a != b) == (n1*d2 != n2*d1));
                }
            }
        }
    }

    //std::cout << "Passed - != grid" << std::endl;
}

TEST(FractionTestSuite,NeRandom) {
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<>
        dis(-32768,32768);
    Fraction a,b;

    for (int32_t i=0;i<NUM_RANDOM;i++) {
        int32_t
            n1 = dis(mt),
            n2 = dis(mt),
            d1,d2;

        do {
            d1 = dis(mt);
        } while (d1 == 0);

        do {
            d2 = dis(mt);
        } while (d2 == 0);

        a = Fraction(n1,d1);
        b = Fraction(n2,d2);

        GTEST_ASSERT_TRUE((a != b) == (n1*d2 != n2*d1));
    }

    //std::cout << "Passed - != random" << std::endl;
}

TEST(FractionTestSuite,LtGrid) {
    Fraction a,b;

    for (int32_t n1=-50;n1<=50;n1++) {
        for (int32_t d1=-50;d1<=50;d1++) {
            if (d1 == 0)
                continue;
            a = Fraction(n1,d1);
            for (int32_t n2=-50;n2<=50;n2++) {
                for (int32_t d2=-50;d2<=50;d2++) {
                    if (d2 == 0)
                        continue;
                    b = Fraction(n2,d2);

                    if (d1 * d2 < 0)
                        GTEST_ASSERT_TRUE((a < b) == (n1*d2 > n2*d1));
                    else
                        GTEST_ASSERT_TRUE((a < b) == (n1*d2 < n2*d1));
                }
            }
        }
    }

    //std::cout << "Passed - < grid" << std::endl;
}

TEST(FractionTestSuite,LtRandom) {
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<>
        dis(-32768,32768);
    Fraction a,b;

    for (int32_t i=0;i<NUM_RANDOM;i++) {
        int32_t
            n1 = dis(mt),
            n2 = dis(mt),
            d1,d2;

        do {
            d1 = dis(mt);
        } while (d1 == 0);

        do {
            d2 = dis(mt);
        } while (d2 == 0);

        a = Fraction(n1,d1);
        b = Fraction(n2,d2);

        if (d1 * d2 < 0)
            GTEST_ASSERT_TRUE((a < b) == (n1*d2 > n2*d1));
        else
            GTEST_ASSERT_TRUE((a < b) == (n1*d2 < n2*d1));
    }

    //std::cout << "Passed - < random" << std::endl;
}

TEST(FractionTestSuite,LeGrid) {
    Fraction a,b;

    for (int32_t n1=-50;n1<=50;n1++) {
        for (int32_t d1=-50;d1<=50;d1++) {
            if (d1 == 0)
                continue;
            a = Fraction(n1,d1);
            for (int32_t n2=-50;n2<=50;n2++) {
                for (int32_t d2=-50;d2<=50;d2++) {
                    if (d2 == 0)
                        continue;
                    b = Fraction(n2,d2);

                    if (d1 * d2 < 0)
                        GTEST_ASSERT_TRUE((a <= b) == (n1*d2 >= n2*d1));
                    else
                        GTEST_ASSERT_TRUE((a <= b) == (n1*d2 <= n2*d1));
                }
            }
        }
    }

    //std::cout << "Passed - <= grid" << std::endl;
}

TEST(FractionTestSuite,LeRandom) {
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<>
        dis(-32768,32768);
    Fraction a,b;

    for (int32_t i=0;i<NUM_RANDOM;i++) {
        int32_t
            n1 = dis(mt),
            n2 = dis(mt),
            d1,d2;

        do {
            d1 = dis(mt);
        } while (d1 == 0);

        do {
            d2 = dis(mt);
        } while (d2 == 0);

        a = Fraction(n1,d1);
        b = Fraction(n2,d2);

        if (d1 * d2 < 0)
            GTEST_ASSERT_TRUE((a <= b) == (n1*d2 >= n2*d1));
        else
            GTEST_ASSERT_TRUE((a <= b) == (n1*d2 <= n2*d1));
    }

    //std::cout << "Passed - <= random" << std::endl;
}

TEST(FractionTestSuite,GtGrid) {
    Fraction a,b;

    for (int32_t n1=-50;n1<=50;n1++) {
        for (int32_t d1=-50;d1<=50;d1++) {
            if (d1 == 0)
                continue;
            a = Fraction(n1,d1);
            for (int32_t n2=-50;n2<=50;n2++) {
                for (int32_t d2=-50;d2<=50;d2++) {
                    if (d2 == 0)
                        continue;
                    b = Fraction(n2,d2);

                    if (d1 * d2 < 0)
                        GTEST_ASSERT_TRUE((a > b) == (n1*d2 < n2*d1));
                    else
                        GTEST_ASSERT_TRUE((a > b) == (n1*d2 > n2*d1));
                }
            }
        }
    }

    //std::cout << "Passed - > grid" << std::endl;
}

TEST(FractionTestSuite,GtRandom) {
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<>
        dis(-32768,32768);
    Fraction a,b;

    for (int32_t i=0;i<NUM_RANDOM;i++) {
        int32_t
            n1 = dis(mt),
            n2 = dis(mt),
            d1,d2;

        do {
            d1 = dis(mt);
        } while (d1 == 0);

        do {
            d2 = dis(mt);
        } while (d2 == 0);

        a = Fraction(n1,d1);
        b = Fraction(n2,d2);

        if (d1 * d2 < 0)
            GTEST_ASSERT_TRUE((a > b) == (n1*d2 < n2*d1));
        else
            GTEST_ASSERT_TRUE((a > b) == (n1*d2 > n2*d1));
    }

    //std::cout << "Passed - > random" << std::endl;
}

TEST(FractionTestSuite,GeGrid) {
    Fraction a,b;

    for (int32_t n1=-50;n1<=50;n1++) {
        for (int32_t d1=-50;d1<=50;d1++) {
            if (d1 == 0)
                continue;
            a = Fraction(n1,d1);
            for (int32_t n2=-50;n2<=50;n2++) {
                for (int32_t d2=-50;d2<=50;d2++) {
                    if (d2 == 0)
                        continue;
                    b = Fraction(n2,d2);

                    if (d1 * d2 < 0)
                        GTEST_ASSERT_TRUE((a >= b) == (n1*d2 <= n2*d1));
                    else
                        GTEST_ASSERT_TRUE((a >= b) == (n1*d2 >= n2*d1));
                }
            }
        }
    }

    //std::cout << "Passed - >= grid" << std::endl;
}

TEST(FractionTestSuite,GeRandom) {
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<>
        dis(-32768,32768);
    Fraction a,b;

    for (int32_t i=0;i<NUM_RANDOM;i++) {
        int32_t
            n1 = dis(mt),
            n2 = dis(mt),
            d1,d2;

        do {
            d1 = dis(mt);
        } while (d1 == 0);

        do {
            d2 = dis(mt);
        } while (d2 == 0);

        a = Fraction(n1,d1);
        b = Fraction(n2,d2);

        if (d1 * d2 < 0)
            GTEST_ASSERT_TRUE((a >= b) == (n1*d2 <= n2*d1));
        else
            GTEST_ASSERT_TRUE((a >= b) == (n1*d2 >= n2*d1));
    }

    //std::cout << "Passed - >= random" << std::endl;
}
