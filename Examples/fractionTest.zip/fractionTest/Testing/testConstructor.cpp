//
// Created by bob on 1/22/26.
//

#include <iostream>
#include <numeric>
#include <random>

#include "gtest/gtest.h"
#include "fraction.h"

const int32_t
    MAX_VAL = 5000,
    NUM_RANDOM = 10000000;

TEST(FractionTestSuite,Constructor2Grid) {
    int32_t
        n,d,
        g;

    for (n=-MAX_VAL; n<=MAX_VAL; n++) {
        //std::cout << "n = " << n << std::endl;
        for (d=-MAX_VAL; d<=MAX_VAL; d++) {
            if (d == 0)
                continue;
            int32_t
                n2 = n,
                d2 = d;

            //std::cout << n2 << "/" << d2 << std::endl;

            Fraction f(n2, d2);;

            g = std::gcd(n2, d2);

            if (d2 < 0) {
                n2 = -n2;
                d2 = -d2;
            }

            n2 /= g;
            d2 /= g;

            GTEST_ASSERT_TRUE((int64_t)n2 * f.getDen() == (int64_t)d2 * f.getNum());
            GTEST_ASSERT_EQ(std::gcd(f.getNum(),f.getDen()),1);
        }
    }

    //std::cout << "Passed - Constructor 2 grid" << std::endl;
}

TEST(FractionTestSuite,Constructor2Random) {
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<>
        dis(-2147483648,2147483647);
    int32_t
       n,d,
       g;

    for (int32_t i=0;i<NUM_RANDOM;i++) {
        n = dis(mt);
        do {
            d = dis(mt);
        } while (d == 0);

        int32_t
            n2 = n,
            d2 = d;

        Fraction f(n2, d2);;

        g = std::gcd(n2, d2);

        if (d2 < 0) {
            n2 = -n2;
            d2 = -d2;
        }

        n2 /= g;
        d2 /= g;

        GTEST_ASSERT_TRUE((int64_t)n2 * f.getDen() == (int64_t)d2 * f.getNum());
        GTEST_ASSERT_EQ(std::gcd(f.getNum(),f.getDen()),1);
    }

    //std::cout << "Passed - Constructor 2 with random values" << std::endl;
}

TEST(FractionTestSuite,Constructor1) {

    // max and min
    Fraction f(2147483647);
    GTEST_ASSERT_EQ(f.getNum(),2147483647);
    GTEST_ASSERT_EQ(f.getDen(),1);

    f = Fraction(-2147483648);
    GTEST_ASSERT_EQ(f.getNum(),-2147483648);

    for (int32_t i=-2000000000;i<=2000000000;i+=10) {
        f = Fraction(i);
        GTEST_ASSERT_EQ(f.getNum(),i);
        GTEST_ASSERT_EQ(f.getDen(),1);
    }

    //std::cout << "Passed - Constructor 1 with min, max and stepped values" << std::endl;
}

TEST(FractionTestSuite,Constructor0) {
    Fraction f;

    GTEST_ASSERT_EQ(f.getNum(),0);
    GTEST_ASSERT_EQ(f.getDen(),1);

    //std::cout << "Passed - Constructor 0" << std::endl;
}