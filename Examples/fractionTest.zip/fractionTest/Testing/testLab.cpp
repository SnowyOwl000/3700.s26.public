//
// Created by bob on 1/21/26.
//

#include <iostream>
#include <sstream>
#include "fraction.h"
#include "gtest/gtest.h"

using namespace std;

TEST(FractionTestSuite,LabTests) {
    Fraction
            f1(42,-301),
            f2(5),
            f3;
    stringstream
            sstr;

    //cout << "Running - Lab test\r"; cout.flush();

    // test 1: constructor
    GTEST_ASSERT_FALSE(f1.getNum() != -6 || f1.getDen() != 43);
    GTEST_ASSERT_FALSE(f2.getNum() != 5 || f2.getDen() != 1);
    GTEST_ASSERT_FALSE(f3.getNum() != 0 || f3.getDen() != 1);

    // output
    sstr << f1;
    GTEST_ASSERT_FALSE(sstr.str() != "-6 / 43");
    sstr.str("");
    sstr << f2;
    GTEST_ASSERT_FALSE(sstr.str() != "5 / 1");
    sstr.str("");
    sstr << f3;
    GTEST_ASSERT_FALSE(sstr.str() != "0 / 1");

    // input
    sstr.str("2/-4");
    sstr >> f1;
    GTEST_ASSERT_TRUE(f1.getNum() == -1 && f1.getDen() == 2);

    // arithmetic
    f1 = Fraction(7,6);
    f2 = Fraction(12,8);

    // +
    f3 = f1 + f2;
    GTEST_ASSERT_TRUE(f3.getNum() == 8 && f3.getDen() == 3);
    f3 = f1 + 2;
    GTEST_ASSERT_TRUE(f3.getNum() == 19 && f3.getDen() == 6);

    // -
    f3 = f1 - f2;
    GTEST_ASSERT_TRUE(f3.getNum() == -1 && f3.getDen() == 3);
    f3 = f1 - 2;
    GTEST_ASSERT_TRUE(f3.getNum() == -5 && f3.getDen() == 6);

    // +
    f3 = f1 * f2;
    GTEST_ASSERT_TRUE(f3.getNum() == 7 && f3.getDen() == 4);
    f3 = f1 * 2;
    GTEST_ASSERT_TRUE(f3.getNum() == 7 && f3.getDen() == 3);

    // +
    f3 = f1 / f2;
    GTEST_ASSERT_TRUE(f3.getNum() == 7 && f3.getDen() == 9);
    f3 = f1 / 2;
    GTEST_ASSERT_TRUE(f3.getNum() == 7 && f3.getDen() == 12);

    // =
    f3 = f1;
    GTEST_ASSERT_TRUE(f1.getNum() == f3.getNum() && f1.getDen() == f3.getDen());

    // ==
    GTEST_ASSERT_TRUE(!(f1 == f2) && (f1 == f1) && !(f1 == 2));

    // !=
    GTEST_ASSERT_TRUE((f1 != f2) && !(f1 != f1) && (f1 != 2));

    // <
    GTEST_ASSERT_TRUE((f1 < f2) && !(f2 < f1) && !(f1 < f1) && (f1 < 2));

    // >
    GTEST_ASSERT_TRUE(!(f1 > f2) && (f2 > f1) && !(f1 > f1) && !(f1 > 2));

    // <=
    GTEST_ASSERT_TRUE((f1 <= f2) && !(f2 <= f1) && (f1 <= f1) && (f1 <= 2));

    // >=
    GTEST_ASSERT_TRUE(!(f1 >= f2) && (f2 >= f1) && (f1 >= f1) && !(f1 >= 2));

    //cout << "Passed - Lab tests" << endl;
}