//
// Created by Robert Kramer on 1/22/26.
//


#include <numeric>
#include <random>
#include <gtest/gtest.h>
#include "fraction.h"

const int32_t
    NUM_RANDOM = 10000000;

TEST(FractionTestSuite,IORandom) {
    std::random_device
        rd;
    std::mt19937
        mt(rd());
    std::uniform_int_distribution<>
        dis(-2147483648,2147483647);
    std::stringstream
        sstr;
    Fraction
        a,b;

    for (int32_t i=0;i<NUM_RANDOM;i++) {
        int32_t
            n1 = dis(mt),
            d1;

        do {
            d1 = dis(mt);
        } while (d1 == 0);

        a = Fraction(n1,d1);

        sstr << a;
        sstr >> b;
        sstr.clear();

        GTEST_ASSERT_TRUE(a == b);
    }

    //std::cout << "Passed - I/O random" << std::endl;
}
