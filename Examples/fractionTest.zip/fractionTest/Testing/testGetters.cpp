//
// Created by Robert Kramer on 1/22/26.
//

#include <gtest/gtest.h>
#include "fraction.h"

TEST(FractionTestSuite,GetNumTest) {

    for (int32_t i=-2000000000;i<=2000000000;i+=10) {
        Fraction f(i,1);
        GTEST_ASSERT_EQ(f.getNum(),i);
        GTEST_ASSERT_EQ(f.getDen(),1);
    }

    //std::cout << "Passed - getNum" << std::endl;
}

TEST(FractionTestSuite,GetDenTest) {

    for (int32_t i=-2000000000;i<=2000000000;i+=10) {
        Fraction f(1,i);
        if (i < 0) {
            GTEST_ASSERT_EQ(f.getDen(),-i);
            GTEST_ASSERT_EQ(f.getNum(),-1);
        } else {
            GTEST_ASSERT_EQ(f.getNum(),1);
            GTEST_ASSERT_EQ(f.getDen(),i);
        }
    }

    //std::cout << "Passed - getDen" << std::endl;
}
