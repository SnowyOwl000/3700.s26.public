//
// Created by bob on 4/20/26.
//

#ifndef DIJKSTRA_HEAP_H
#define DIJKSTRA_HEAP_H
#include <cstdint>


class Heap {
public:
    Heap(int32_t size);
    ~Heap();

    void insert(int32_t key,int32_t value);
    int32_t remove(int32_t vNum=-1);
    bool check() const;

private:
    int32_t
        *keys,
        *values,
        *loc,
        count;
};



#endif //DIJKSTRA_HEAP_H
