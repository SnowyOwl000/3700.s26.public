//
// Created by bob on 4/20/26.
//

#include <iostream>
#include "heap.h"

//=============================================================================
// Heap::Heap(const int32_t size)
//  initialize empty heap with given capacity
//

Heap::Heap(const int32_t size) {

    count = 0;
    keys = new int32_t[size];
    values = new int32_t[size];
    loc = new int32_t[size];
}

//=============================================================================
// Heap::~Heap()
//  destructor - just deletes arrays
//

Heap::~Heap() {

    delete[] keys;
    delete[] values;
    delete[] loc;
}

//=============================================================================
// void Heap::insert(const int32_t key, const int32_t value)
//  insert new key-value pair into heap
//

void Heap::insert(const int32_t key, const int32_t value) {
    int32_t
        pos = count++;                  // starting position of new pair, plus we have one more pair

    // while we aren't at the root
    while (pos != 0) {
        const int32_t
            parent = (pos - 1) / 2;     // parent node

        if (keys[parent] <= key)        // if parent is smaller than new key, stop
            break;

        keys[pos] = keys[parent];       // move parent pair down to current position
        values[pos] = values[parent];
        loc[values[pos]] = pos;         // remember where the vertex' heap element is now located

        pos = parent;                   // move up the heap
    }

    // when we stop, we are at the position where the new key belongs
    keys[pos] = key;        // add new pair here
    values[pos] = value;
    loc[value] = pos;       // remember where we parked
}

//=============================================================================
// int32_t Heap::remove(const int32_t vNum)
//  remove the given vertex from the heap
//
// Note: if no vertex is given, remove the root of the heap (deleteMin)
//

int32_t Heap::remove(const int32_t vNum) {
    int32_t
        pos;

    // given the vertex number, find its location in the heap
    // default value is -1, that indicates remove the root
    if (vNum < 0)
        pos = 0;
    else
        pos = loc[vNum];

    const int32_t
        v = values[pos];    // remember vertex number being removed

    loc[v] = -1;            // clear it in the location array

    count--;                // one less vertex

    const int32_t                   // grab the last node in the heap
        tmpKey = keys[count],
        tmpValue = values[count];

    // move temp node up toward the root if necessary to preserve heap property
    while (pos != 0) {
        const int32_t
            parent = (pos - 1) / 2;

        if (keys[parent] <= tmpKey)
            break;

        keys[pos] = keys[parent];
        values[pos] = values[parent];
        loc[values[pos]] = pos;

        pos = parent;
    }

    // now move down the heap (fixHeap) and restore heap property as needed
    while (pos < count / 2) {
        int32_t
            child = 2 * pos + 1;        // left child

        // if there is a right child and it is smaller than left child
        if (child+1 < count && keys[child] > keys[child+1])
            child++;        // ... choose the right child

        if (tmpKey <= keys[child])  // if temp node smaller, stop walking down the heap
            break;

        // move child up to current location
        keys[pos] = keys[child];
        values[pos] = values[child];
        loc[values[pos]] = pos;

        pos = child;    /// move down the heap
    }

    // this is where the temp node belongs, place it here
    keys[pos] = tmpKey;
    values[pos] = tmpValue;
    loc[tmpValue] = pos;

    // return the vertex we just removed
    return v;
}

//=============================================================================
// bool Heap::check() const
//  check heap property at all nodes
//

bool Heap::check() const {
    int32_t
        i,c;

    // compare internal nodes against children
    for (i=0;i<count/2;i++) {
        c = 2 * i + 1;
        if (c >= count)
            return true;
        if (keys[i] > keys[c]) {
            std::cout << "check " << count << ' ' << i << ' ' << keys[i] << ' ' << c << ' ' << keys[c] << std::endl;
            return false;
        }
        c++;
        if (c >= count)
            return true;
        if (keys[i] > keys[c]) {
            std::cout << "check " << count << ' ' << i << ' ' << keys[i] << ' ' << c << ' ' << keys[c] << std::endl;
            return false;
        }
    }
    return true;
}