#include <iostream>
#include <vector>
#include <chrono>

#include "heap.h"
#include "sampler.h"

using namespace std;
using namespace std::chrono;

const int32_t
    N_VERTICES = 10000,             // number of vertices in random graph; upper limit is probably around 10K
    N_EDGES = 100000,               // number of edges in random graph
    INF = 0x3fffffff;               // a representation of infinity, bigger than numbers we calculate but small enough to avoid overflow

int32_t
    adj[N_VERTICES][N_VERTICES];    // adjacency matrix, INF == no edge

vector<vector<int32_t>>
    adjList(N_VERTICES);            // adjacency list

bool
    selected[N_VERTICES];           // selected array for Dijkstra
int32_t
    parent[3][N_VERTICES],          // 3 sets of parents, one for each Dijkstra variation
    cost[3][N_VERTICES];            // 3 sets of costs, same reason

//=============================================================================
// void dijkstra1()
//  Dijkstra's algorithm using adjacency matrix, brute-force findMin

void dijkstra1() {
    int32_t
        i,j,v,w;

    // initialize, all vertices unselected, infinite cost, no parent
    for (i=0;i<N_VERTICES;i++) {
        selected[i] = false;
        cost[0][i] = INF;
        parent[0][i] = -1;
    }
    cost[0][0] = 0;                 // destination has no cost

    for (i=0;i<N_VERTICES-1;i++) {          // loop |v| - 1 times
        for (j=0;j<N_VERTICES;j++)              // find any unselected vertex
            if (!selected[j])
                break;
        v = j;
        for (j++;j<N_VERTICES;j++)              // continue on, looking for unselected vertex with least cost
            if (!selected[j] && cost[0][j] < cost[0][v])
                v = j;

        selected[v] = true;                     // select that vertex
        if (cost[0][v] == INF)                  // if cost is infinite, then graph is disconnected and we've reached
            return;                             // all vertices so step

        // look at all adjacent vertices
        for (w=0;w<N_VERTICES;w++)
            // unselected and better path found?
            if (!selected[w] && cost[0][v] + adj[v][w] < cost[0][w]) {
                parent[0][w] = v;                       // update parent and cost
                cost[0][w] = cost[0][v] + adj[v][w];
            }
    }
}

//=============================================================================
// void dijkstra2()
//  Dijkstra using adjacency list, brute-force findMin
//

void dijkstra2() {
    int32_t
        i,j,v;

    // same initialization as version 1
    for (i=0;i<N_VERTICES;i++) {
        selected[i] = false;
        cost[1][i] = INF;
        parent[1][i] = -1;
    }
    cost[1][0] = 0;

    for (i=0;i<N_VERTICES-1;i++) {      // same loop here

        // same findMin as before
        for (j=0;j<N_VERTICES;j++)
            if (!selected[j])
                break;
        v = j;
        for (;j<N_VERTICES;j++)
            if (!selected[j] && cost[1][j] < cost[1][v])
                v = j;

        selected[v] = true;
        if (cost[1][v] == INF)
            return;

        // update using adjacency list
        for (auto w : adjList[v])
            if (!selected[w] && cost[1][v] + adj[v][w] < cost[1][w]) {
                parent[1][w] = v;
                cost[1][w] = cost[1][v] + adj[v][w];
            }
    }
}

//=============================================================================
// void dijkstra3()
//  Dijkstra using adjacency list and min heap for findMin
//

void dijkstra3() {
    int32_t
        i,v;
    Heap
        h(N_VERTICES);

    // starts the same
    for (i=0;i<N_VERTICES;i++) {
        selected[i] = false;
        cost[2][i] = INF;
        parent[2][i] = -1;
    }
    cost[2][0] = 0;
    // differs here
    // add vertices to heap
    for (i=0;i<N_VERTICES;i++)
        h.insert(cost[2][i],i);

    for (i=0;i<N_VERTICES-1;i++) {
        // use heap to get min unselected vertex
        v = h.remove();

        selected[v] = true;
        if (cost[2][v] == INF)
            return;

        // use adjacency list to find adjacent vertices
        for (auto w : adjList[v])
            // unselected and better path?
            if (!selected[w] && cost[2][v] + adj[v][w] < cost[2][w]) {
                // update cost and parent
                parent[2][w] = v;
                cost[2][w] = cost[2][v] + adj[v][w];
                // replace the vertex in the heap
                if (w != h.remove(w)) {
                    cout << "Error: Bad remove" << endl;
                    return;
                }
                h.insert(cost[2][w],w);
            }
    }
}

//=============================================================================
// int main()
//

int main() {
    Sampler
        edges(N_VERTICES * N_VERTICES);         // sampler to generate random edges in graph
    random_device
        rd;                                     // random objects for edge costs
    mt19937
        mt(rd());
    uniform_int_distribution<int32_t>
        dis(1,1000);
    int32_t
        v,w,e,d;

    cout << "Generating graph" << endl;

    for (auto & i : adj)            // initialize matrix to all INF values
        for (int & j : i)
            j = INF;

    for (uint32_t i = 0; i < N_EDGES; i++) {    // add random edges
        // pick a random edge such that v < w. Guarantees we won't add v - w and later add w - v
        do {
            e = edges.getSample();
            v = e / N_VERTICES;
            w = e % N_VERTICES;
        } while (v >= w);

        d = dis(mt);                 // random edge cost
        adj[v][w] = adj[w][v] = d;      // add edge to matrix
        adjList[v].push_back(w);        // add edge to adjacency lists
        adjList[w].push_back(v);        // in both directions
    }

    // run the tests, timing each one
    cout << "Dijkstra with adjacency matrix" << endl;

    auto
        start = high_resolution_clock::now();

    dijkstra1();

    auto
        end = high_resolution_clock::now();

    auto
        time1 = duration_cast<microseconds>(end-start);

    cout << "Time: " << time1.count() << " microseconds" << endl;

    cout << "Dijkstra with adjacency list" << endl;

    start = high_resolution_clock::now();

    dijkstra2();

    end = high_resolution_clock::now();

    auto
        time2 = duration_cast<microseconds>(end-start);

    cout << "Time: " << time2.count() << " microseconds" << endl;

    // verify costs are the same for all vertices
    // note: parents might be different, there might be multiple shortest paths and the different
    //       versions might find different paths, so don't check parents, only costs
    for (uint32_t i=0;i<N_VERTICES;i++)
        if (cost[0][i] != cost[1][i]) {
            cout << "Error at vertex " << i << "  " << cost[0][i] << "  " << cost[1][i] << endl;
            break;
        }

    cout << "Dijkstra with adjacency list and heap" << endl;

    start = high_resolution_clock::now();

    dijkstra3();

    end = high_resolution_clock::now();

    auto
        time3 = duration_cast<microseconds>(end-start);

    cout << "Time: " << time3.count() << " microseconds" << endl;

    // verify version 3 gives same results
    for (uint32_t i=0;i<N_VERTICES;i++)
        if (cost[0][i] != cost[2][i]) {
            cout << "Error at vertex " << i << "  " << cost[0][i] << "  " << cost[1][i] << "  " << cost[2][i] << endl;
            break;
        }

    return 0;
}